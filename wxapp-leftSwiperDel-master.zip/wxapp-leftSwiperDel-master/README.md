# wxapp-leftSwiperDel
微信小程序---左滑删除

#效果图
![mahua](http://a3767c8e05b9af00df2d.b0.upaiyun.com/apicloud/05e36d4e5e46fddf6a8e42e47ba99d35.gif)
